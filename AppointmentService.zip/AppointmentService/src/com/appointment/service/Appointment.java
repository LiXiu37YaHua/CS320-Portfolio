package com.appointment.service;
/**
 * Author: Marissa Lanza
 * Date: 2024-6-10
 * Course ID: CS-320-13376-M01
 * Description: This class represents an appointment with a unique ID, date, and description.
 */
import java.util.Date;

public class Appointment {
    private final String appointmentId; // Unique appointment ID
    private final Date appointmentDate; // Appointment Date
    private final String description; // Appointment description

    public Appointment(String appointmentId, Date appointmentDate, String description) {
        if (appointmentId == null || appointmentId.length() > 10) {
            throw new IllegalArgumentException("Appointment ID must be a non-null string with a maximum length of 10 characters.");
        }
        if (appointmentDate == null || appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Appointment date must not be null and cannot be in the past.");
        }
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Description must be a non-null string with a maximum length of 50 characters.");
        }
        this.appointmentId = appointmentId;
        this.appointmentDate = appointmentDate;
        this.description = description;
    }

    public String getAppointmentId() {
        return appointmentId;
    }

    public Date getAppointmentDate() {
        return appointmentDate;
    }

    public String getDescription() {
        return description;
    }
}
