package com.appointment.service;
/**
 * Author: Marissa Lanza
 * Date: 2024-6-10
 * Course ID: CS-320-13376-M01
 * Description: This class represents an appointment with a unique ID, date, and description.
 */
import org.junit.jupiter.api.Test;
import java.util.Date;
import static org.junit.jupiter.api.Assertions.*;

public class AppointmentTest {
    @Test
    public void testValidAppointmentCreation() {
        Appointment appointment = new Appointment("1234567890", new Date(System.currentTimeMillis() + 86400000), "Doctor's Appointment");
        assertNotNull(appointment);
        assertEquals("1234567890", appointment.getAppointmentId());
        assertEquals("Doctor's Appointment", appointment.getDescription());
    }

    @Test
    public void testAppointmentIdTooLong() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345678901", new Date(System.currentTimeMillis() + 86400000), "Doctor's Appointment");
        });
        assertEquals("Appointment ID must be a non-null string with a maximum length of 10 characters.", exception.getMessage());
    }

    @Test
    public void testAppointmentDateInThePast() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("1234567890", new Date(System.currentTimeMillis() - 86400000), "Doctor's Appointment");
        });
        assertEquals("Appointment date must not be null and cannot be in the past.", exception.getMessage());
    }

    @Test
    public void testDescriptionTooLong() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("1234567890", new Date(System.currentTimeMillis() + 86400000), 
                "This description is way too long for the defined limit of fifty characters.");
        });
        assertEquals("Description must be a non-null string with a maximum length of 50 characters.", exception.getMessage());
    }
}
