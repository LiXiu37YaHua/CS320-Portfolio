package com.appointment.service;
/**
 * Author: Marissa Lanza
 * Date: 2024-6-10
 * Course ID: CS-320-13376-M01
 * Description: This class represents an appointment with a unique ID, date, and description.
 */
import org.junit.jupiter.api.Test;

import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

public class AppointmentServiceTest {
    @Test
    public void testAddAppointment() {
        AppointmentService service = new AppointmentService();
        Appointment appointment = new Appointment("1234567890", new Date(System.currentTimeMillis() + 86400000), "Doctor's Appointment");
        service.addAppointment(appointment);
        assertEquals(appointment, service.getAppointment("1234567890"));
    }

    @Test
    public void testAddDuplicateAppointment() {
        AppointmentService service = new AppointmentService();
        Appointment appointment = new Appointment("1234567890", new Date(System.currentTimeMillis() + 86400000), "Doctor's Appointment");
        service.addAppointment(appointment);
        
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment(appointment);
        });
        assertEquals("Appointment ID must be unique.", exception.getMessage());
    }

    @Test
    public void testDeleteAppointment() {
        AppointmentService service = new AppointmentService();
        Appointment appointment = new Appointment("1234567890", new Date(System.currentTimeMillis() + 86400000), "Doctor's Appointment");
        service.addAppointment(appointment);
        service.deleteAppointment("1234567890");
        assertNull(service.getAppointment("1234567890"));
    }

    @Test
    public void testDeleteNonExistentAppointment() {
        AppointmentService service = new AppointmentService();
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            service.deleteAppointment("nonExistentId");
        });
        assertEquals("Appointment ID does not exist.", exception.getMessage());
    }
}
