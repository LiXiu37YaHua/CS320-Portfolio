package com.example.taskmanagement; // Added package declaration
// Author Name: Marissa Lanza
// Date: 9/27/2024
// Course ID: CS-320-13376
// Description: Unit tests for the Task class.

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TaskTest {
    @Test
    public void testCreateTask() {
        Task task = new Task("123456789", "Test Task", "This is a test task.");
        assertNotNull(task);
        assertEquals("Test Task", task.getName());
        assertEquals("This is a test task.", task.getDescription());
    }

    @Test
    public void testTaskIdTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345678901", "Test Task", "This is a test task.");
        });
    }

    @Test
    public void testNameTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("123456789", "This name is way too long", "Description");
        });
    }

    @Test
    public void testDescriptionTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("123456789", "Test Task", "This description is definitely longer than fifty characters and should throw an error.");
        });
    }
}
