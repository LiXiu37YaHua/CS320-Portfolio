package com.example.taskmanagement; // Added package declaration
// Author Name: Marissa Lanza
// Date: 9/27/2024
// Course ID: CS-320-13376
// Description: This class represents a task with a unique ID, name, and description.

public class Task {
    private final String taskId; // Unique task ID
    private String name;          // Task name
    private String description;   // Task description

    // Constructor
    public Task(String taskId, String name, String description) {
        if (taskId == null || taskId.length() > 10) {
            throw new IllegalArgumentException("Task ID cannot be null and must be 10 characters or less.");
        }
        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException("Task name cannot be null and must be 20 characters or less.");
        }
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Task description cannot be null and must be 50 characters or less.");
        }
        this.taskId = taskId;
        this.name = name;
        this.description = description;
    }

    // Getters
    public String getTaskId() {
        return taskId;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    // Setters for updatable fields
    public void setName(String name) {
        if (name.length() > 20) {
            throw new IllegalArgumentException("Task name cannot be longer than 20 characters.");
        }
        this.name = name;
    }

    public void setDescription(String description) {
        if (description.length() > 50) {
            throw new IllegalArgumentException("Task description cannot be longer than 50 characters.");
        }
        this.description = description;
    }
}
