package com.example.taskmanagement; // Added package declaration
// Author Name: Marissa Lanza
// Date: 9/27/2024
// Course ID: CS-320-13376
// Description: This class manages tasks, allowing addition, deletion, and updates.

import java.util.HashMap;
import java.util.Map;

public class TaskService {
    private Map<String, Task> tasks = new HashMap<>(); // In-memory storage for tasks

    // Add a task
    public void addTask(Task task) {
        if (tasks.containsKey(task.getTaskId())) {
            throw new IllegalArgumentException("Task ID already exists.");
        }
        tasks.put(task.getTaskId(), task);
    }

    // Delete a task by ID
    public void deleteTask(String taskId) {
        tasks.remove(taskId);
    }

    // Update a task by ID
    public Task updateTask(String taskId, String name, String description) {
        Task task = tasks.get(taskId);
        if (task != null) {
            if (name != null) {
                task.setName(name);
            }
            if (description != null) {
                task.setDescription(description);
            }
        }
        return task;
    }

    // Get a task by ID
    public Task getTask(String taskId) {
        return tasks.get(taskId);
    }
}
