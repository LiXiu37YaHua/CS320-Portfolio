package com.example.taskmanagement; // Added package declaration
// Author Name: Marissa Lanza
// Date: 9/27/2024
// Course ID: CS-320-13376
// Description: Unit tests for the TaskService class.

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TaskServiceTest {
    private TaskService taskService;

    @BeforeEach
    public void setUp() {
        taskService = new TaskService();
    }

    @Test
    public void testAddTask() {
        Task task = new Task("123456789", "Test Task", "This is a test task.");
        taskService.addTask(task);
        assertEquals(task, taskService.getTask("123456789"));
    }

    @Test
    public void testAddDuplicateTask() {
        Task task1 = new Task("123456789", "Task 1", "First Task");
        taskService.addTask(task1);
        assertThrows(IllegalArgumentException.class, () -> {
            Task task2 = new Task("123456789", "Task 2", "Second Task");
            taskService.addTask(task2);
        });
    }

    @Test
    public void testUpdateTask() {
        Task task = new Task("123456789", "Test Task", "This is a test task.");
        taskService.addTask(task);
        taskService.updateTask("123456789", "Updated Task", "Updated Description");
        assertEquals("Updated Task", taskService.getTask("123456789").getName());
        assertEquals("Updated Description", taskService.getTask("123456789").getDescription());
    }

    @Test
    public void testDeleteTask() {
        Task task = new Task("123456789", "Test Task", "This is a test task.");
        taskService.addTask(task);
        taskService.deleteTask("123456789");
        assertNull(taskService.getTask("123456789"));
    }
}
