package contactmanagement;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class ContactServiceTest {
    private ContactService service;
    private Contact contact1;
    private Contact contact2;

    @Before
    public void setUp() {
        // Initialize ContactService and add some contacts before each test
        service = new ContactService();
        contact1 = new Contact("001", "Alice", "Smith", "1234567890", "123 Main St");
        contact2 = new Contact("002", "Bob", "Jones", "0987654321", "456 Elm St");
        service.addContact(contact1);
        service.addContact(contact2);
    }

    @Test
    public void testAddContact() {
        // Test adding a new contact successfully
        Contact newContact = new Contact("003", "Carol", "White", "1112223333", "789 Oak St");
        service.addContact(newContact);
        assertEquals(newContact, service.getContact("003"));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAddDuplicateContact() {
        // Test adding a contact with an existing ID
        Contact duplicateContact = new Contact("001", "David", "Brown", "2223334444", "987 Maple St");
        service.addContact(duplicateContact);
    }

    @Test
    public void testDeleteContact() {
        // Test deleting an existing contact
        service.deleteContact("001");
        assertNull(service.getContact("001"));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testDeleteNonexistentContact() {
        // Test deleting a non-existent contact
        service.deleteContact("999");
    }

    @Test
    public void testUpdateContact() {
        // Test updating an existing contact's information
        service.updateContact("002", "Bobby", "Johnson", null, null);
        Contact updatedContact = service.getContact("002");
        assertEquals("Bobby", updatedContact.getFirstName());
        assertEquals("Johnson", updatedContact.getLastName());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testUpdateNonexistentContact() {
        // Test updating a non-existent contact
        service.updateContact("999", "Cherry", "Bloom", "3334445555", "123 Cherry Ln");
    }
}
