package contactmanagement;

import java.util.HashMap;
import java.util.Map;

public class ContactService {
    private Map<String, Contact> contacts = new HashMap<>();

    public ContactService() {
        // Initially empty, ready to store contacts.
    }

    // Method to add a contact
    public void addContact(Contact contact) {
        if (contact == null) {
            throw new IllegalArgumentException("Cannot add a null contact.");
        }
        if (contacts.containsKey(contact.getContactId())) {
            throw new IllegalArgumentException("Contact with ID " + contact.getContactId() + " already exists.");
        }
        contacts.put(contact.getContactId(), contact);
    }

    // Method to remove a contact by ID
    public void deleteContact(String contactId) {
        if (!contacts.containsKey(contactId)) {
            throw new IllegalArgumentException("No contact found with ID: " + contactId);
        }
        contacts.remove(contactId);
    }

    // Method to update an existing contact's information
    public void updateContact(String contactId, String firstName, String lastName, String phone, String address) {
        Contact contact = contacts.get(contactId);
        if (contact == null) {
            throw new IllegalArgumentException("No contact found with ID: " + contactId);
        }
        if (firstName != null && !firstName.isEmpty()) {
            contact.setFirstName(firstName);
        }
        if (lastName != null && !lastName.isEmpty()) {
            contact.setLastName(lastName);
        }
        if (phone != null && !phone.isEmpty()) {
            contact.setPhone(phone);
        }
        if (address != null && !address.isEmpty()) {
            contact.setAddress(address);
        }
    }

    // Method to retrieve a contact by ID
    public Contact getContact(String contactId) {
        return contacts.get(contactId);
    }
}
