package contactmanagement;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class ContactTest {
    private Contact contact;

    @Before
    public void setUp() {
        // Create a contact object before each test
        contact = new Contact("001", "Alice", "Smith", "1234567890", "123 Main St");
    }

    @Test
    public void testContactCreation() {
        // Test successful contact creation
        assertEquals("Alice", contact.getFirstName());
        assertEquals("Smith", contact.getLastName());
        assertEquals("1234567890", contact.getPhone());
        assertEquals("123 Main St", contact.getAddress());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testInvalidContactId() {
        // Test contact creation with invalid ID (null or too long)
        new Contact("01234567890", "Jane", "Doe", "2345678901", "456 Oak St");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testInvalidFirstName() {
        // Test setting an invalid first name (null or too long)
        contact.setFirstName("Aliceeeeeeeeeeeeeeee");  // Assuming the limit is 10 characters
    }

    @Test
    public void testValidPhoneUpdate() {
        // Test updating the phone number successfully
        contact.setPhone("0987654321");
        assertEquals("0987654321", contact.getPhone());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testInvalidPhoneUpdate() {
        // Test updating with an invalid phone number (non-digits included)
        contact.setPhone("1234abc890");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testInvalidAddress() {
        // Test setting an invalid address (too long or null)
        contact.setAddress("");
    }
}
